#include "TestHarness.h"

// testRec* simpleCalTest(int testNum);
// testRec* medCalTest(int testNum);
// testRec* largeCalTest(int testNum);
// testRec* foldedCalTest(int testNum);
// testRec* megaCalTestRead(int testNum);

testRec* _tValidFileTest1(int testNum);
testRec* _tValidFileTest2(int testNum);
testRec* _tValidFileTest3(int testNum);
testRec* _tValidFileTest4(int testNum);
testRec* _tValidFileTest5(int testNum);
testRec* _tValidFileTest6(int testNum);
testRec* _tValidFileTest7(int testNum);
testRec* _tValidFileTest8(int testNum);
testRec* _tValidFileTest9(int testNum);
testRec* _tValidFileTest10(int testNum);
testRec* _tValidFileTest11(int testNum);
testRec* _tValidFileTest12(int testNum);
testRec* _tValidFileTest13(int testNum);

testRec* _tInvFileTest(int testNum);

testRec* _tInvCalTest(int testNum);
testRec* _tInvProdIDTest(int testNum);
testRec* _tInvVerTest(int testNum);

testRec* _tInvEvtTest(int testNum);

testRec* _tInvDTTest(int testNum);

testRec* _tInvAlmTest(int testNum);

testRec* _tPrintCalTest(int testNum);

testRec* _tDeleteCalTest(int testNum);

testRec* _tPrintErrTest(int testNum);

//A2
testRec* paramsTest(int testNum);
testRec* validateTest(int testNum);
testRec* outputTest(int testNum);
testRec* megaCalTestWrite(int testNum);

