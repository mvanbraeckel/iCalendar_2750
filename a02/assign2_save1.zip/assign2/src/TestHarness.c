/*
 * @author Mitchell Van Braeckel (mvanbrae@uoguelph.ca) 1002297
 * @course CIS*2750: Software Systems Integration and Development - A1
 * @version 27/01/2019
 * @file TestHarness.c
 * @brief Runs the main to test stuff
 */

// ============================== INCLUDES ==============================
//#include "LinkedListAPI.h"
#include "CalendarParser.h"
#include "ParserHelper.h"

// ======================================================================

int main(int argc, char **argv) {
    // testing createCalendar
    Calendar *myCal;
    
    //ICalErrorCode wasReturned = createCalendar("mLineProp1.ics", &myCal);
    //ICalErrorCode wasReturned = createCalendar("testCalEvtProp.ics", &myCal);
    //ICalErrorCode wasReturned = createCalendar("testCalSimpleNoUTC.ics", &myCal);
    //ICalErrorCode wasReturned = createCalendar("testCalSimpleUTCComments.ics", &myCal);
    ICalErrorCode wasReturned = createCalendar("testCalEvtPropAlm.ics", &myCal);

    //ICalErrorCode wasReturned = createCalendar("missingEndCal.ics", &myCal);

    //ICalErrorCode wasReturned = createCalendar("my.ics", &myCal);

    char* errorStr = printError(wasReturned);
    printf("ICalErrorCode from createCalendar = '%s'\n", errorStr);
    free(errorStr);

    if(myCal == NULL) {
        printf("cal is null\n");
    } else {
        printf("cal not null\n");
    }

    char *s = printCalendar(myCal);
    printf("Now printing the calendar:\n\n%s\n", s);
    free(s);

    // ===================

    char *perr = printError(writeCalendar("my.ics", myCal));
    printf("write cal: %s\n", perr);
    free(perr);

    char *verr = printError(validateCalendar(myCal));
    printf("validate cal: %s\n", verr);
    free(verr);

    // ===================

    // cal + JSON testing

    char* calAsJSON = calendarToJSON(myCal);
    printf("\ncalAsJSON:\n%s\n", calAsJSON);
    free(calAsJSON);
    
    Calendar *tempCal1 = JSONtoCalendar("{\"version\":2,\"prodID\":\"-//hacksw/handcal//NONSGML v1.0//EN\"}");
    if(tempCal1 != NULL) {
        char* calAsJSONcheck = printCalendar(tempCal1);
        printf("\ntempCal1 from created JSON being printed:\n\n%s\n", calAsJSONcheck);
        free(calAsJSONcheck);
        deleteCalendar(tempCal1);
    } else {
        printf("\ntempCal1 from created JSON was null\n");
    }

    Calendar *tempCal2 = JSONtoCalendar("{\"version\":12345.12345678,\"prodID\":\"a\"}");
    if(tempCal2 != NULL) {
        char* calAsJSONcheck = printCalendar(tempCal2);
        printf("\ntempCal2 from created JSON being printed:\n\n%s\n", calAsJSONcheck);
        free(calAsJSONcheck);
        deleteCalendar(tempCal2);
    } else {
        printf("\ntempCal2 from created JSON was null\n");
    }

    // ===================
    
    // event + JSON testing

    ListIterator evPropIter = createIterator(myCal->events);
	Event* ev;
	while( (ev = nextElement(&evPropIter)) != NULL ) {
        char* evAsJSON = eventToJSON(ev);
        printf("\nevAsJSON:\n%s\n", evAsJSON);
        free(evAsJSON);
    }

    Event *tempEv1 = JSONtoEvent("{\"UID\":\"myValue\"}");
    if(tempEv1 != NULL) {
        printf("\ntempEv1 from created JSON being printed:\n\nUID = '%s'\n", tempEv1->UID);
        deleteEvent(tempEv1);
    } else {
        printf("\ntempEv1 from created JSON was null\n");
    }

    Event *tempEv2 = JSONtoEvent("{\"UID\":\"a\"}");
    if(tempEv2 != NULL) {
        printf("\ntempEv2 from created JSON being printed:\n\nUID = '%s'\n", tempEv2->UID);
        deleteEvent(tempEv2);
    } else {
        printf("\ntempEv2 from created JSON was null\n");
    }

    // ===================

    deleteCalendar(myCal);

    /*NOTE: these are all true
    if(CR == '\r') {
        printf("CR = \\r confirmed!\n");
    }
    if(LF == '\n') {
        printf("LF = \\n confirmed!\n");
    }
    char s[3];
    s[0] = CR;
    s[1] = LF;
    s[2] = '\0';
    if(strcmp(s, "\r\n") == 0) {
        printf("CRLF\\0 = \\r\\n confirmed!\n");
    }*/

    /*char str[40] = "{\"version\":verVal,\"prodID\":\"prodIDVal\"}";
    char myS[40];
    float myF = 0.0;
    sscanf(str, "%s:%f", myS, &myF);
    char ff[100] = "2.9}";
    myF = atof(ff);
    printf("myS = '%s' | myF = '%f'\n", myS, myF);*/

    /*char validEvPropsOnceNames[17][15] = { "CLASS", "CREATED", "DESCRIPTION", "GEO", "LAST-MODIFIED", "LOCATION", "ORGANIZER", "PRIORITY",
			"SEQUENCE", "STATUS", "SUMMARY", "TRANSP", "URL", "RECURRENCE-ID", "RRULE", "DTEND", "DURATION" };
    for(int i = 0; i < 17; i++) {
        if(strchr(validEvPropsOnceNames[i], '\0') == NULL) {
            printf("\tprop[%d] ('%s') null char missing\n", i, validEvPropsOnceNames[i]);
        } else {
            printf("prop[%d] ('%s') null char found\n", i, validEvPropsOnceNames[i]);
        }
    }*/

    return 0;
}